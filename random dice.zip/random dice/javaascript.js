const input1 = document.getElementById("input1");
const res = document.getElementById("res");
var imm = [];

function generate() {
    imm = [];  
    const inputValue = Number(input1.value);  
    for (let i = 1; i <= inputValue; i++) {
        let ran = Math.floor(Math.random() * 6) + 1;
        imm.push(`<img src="imgs/${ran}.png" alt="Random Image">`);
    }
    res.innerHTML = imm.join('');
}