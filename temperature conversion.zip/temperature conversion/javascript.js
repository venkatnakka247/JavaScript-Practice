const input1 = document.getElementById("input1");
const sel1 = document.getElementById("sel1");
const sel2 = document.getElementById("sel2");
const res = document.getElementById("res");
var temp;
function conversion(){
    if(sel1.checked){
        temp=Number(input1.value);
        temp=temp * 9/5 + 32;
        res.textContent= temp + " F"
    }
    else if(sel2.checked){
        temp=Number(input1.value);
        temp=(temp- 32)* 5/9 ;
        res.textContent=temp + " C"
    }
    else{
        res.textContent("Select a unit");
    }

}