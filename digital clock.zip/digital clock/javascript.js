function runt(){
    const now = new Date();
    const hours = now.getHours().toString().padStart(2,0);
    const sec = now.getSeconds().toString().padStart(2,0);
    const mins =now.getMinutes().toString().padStart(2,0);
    const time = `${hours}:${mins}:${sec}`;
    document.getElementById("clock").textContent = time;
}
runt();
setInterval(runt,1000);